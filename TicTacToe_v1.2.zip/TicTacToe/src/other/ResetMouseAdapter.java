package other;

import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import component.Prompt;
import gameState.GameState;
import mainBody.TicTacToe;

public class ResetMouseAdapter extends MouseAdapter{
	private TicTacToe frame;
	public ResetMouseAdapter(TicTacToe frame){
		this.frame=frame;
	}
	public void mouseClicked(MouseEvent e) {
		GameState.reset();
		frame.initialPanel();
		frame.setVisible(true);
	}
}
