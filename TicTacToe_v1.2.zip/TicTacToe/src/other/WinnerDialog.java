package other;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JButton;
import javax.swing.JDialog;
import component.Text;

public class WinnerDialog extends JDialog {
	JDialog wd=this;
	public WinnerDialog(int winner) {
		setTitle("Game Over");
		setLayout(null);
		String str=String.format("Winner is player%d!", winner);
		Dimension screensize=Toolkit.getDefaultToolkit().getScreenSize();
		setBounds((screensize.width-300)/2, (screensize.height-200)/2, 300, 200);
		getContentPane().setBackground(new Color(191,235,234));
		add(new Text(str,0,30,280,40,Color.DARK_GRAY,20));
		JButton btn=new JButton("OK");
		btn.setBounds(120, 100, 60, 30);
		btn.setBackground(Color.LIGHT_GRAY);
		btn.setFocusPainted(false);
		btn.addMouseListener(new MouseAdapter(){
			public void mouseClicked(MouseEvent e) {
				wd.dispose();
			}
		});
		add(btn);
		setVisible(true);
	}
}
