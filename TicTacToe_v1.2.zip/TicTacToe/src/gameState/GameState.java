package gameState;

public class GameState {
	public static int turn=1;
	public static int p1State[][]=new int[3][3];
	public static int p2State[][]=new int[3][3];
	public static int ownerState[][]=new int[3][3];
	public static void reset() {
		turn=1;
		p1State=new int[3][3];
		p2State=new int[3][3];
		ownerState=new int[3][3];
	}
}