package mainBody;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.EventQueue;
import java.awt.Toolkit;
import java.io.IOException;

import javax.swing.JFrame;
import javax.swing.JPanel;

import component.Block;
import component.Board;
import component.Piece;
import component.Prompt;
import component.ResetButton;
import component.Text;

public class TicTacToe extends JFrame {
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					TicTacToe frame = new TicTacToe();
					frame.setResizable(false);
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	public TicTacToe(){
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		Dimension screensize=Toolkit.getDefaultToolkit().getScreenSize();
		setBounds((screensize.width-700)/2, (screensize.height-480)/2, 700, 480);
		setTitle("TicTacToe Game v1.2");
		initialPanel();
	}
	
	public void initialPanel(){
		JPanel panel=new JPanel();
		setContentPane(panel);
		panel.setLayout(null);
		panel.setBackground(new Color(125,155,185));
		
		//�ַ�����
		panel.add(new Text("TicTacToe", 0, 10, 700, 40, Color.WHITE, 20));
		panel.add(new Block(new Color(75,107,139), 0, 0, 700, 55));
		panel.add(new Text("P1's pieces", 20, 50, 165, 90, Color.DARK_GRAY, 18));
		panel.add(new Text("P2's pieces", 515, 50, 165, 90, Color.DARK_GRAY, 18));
		
		//��ʾ��Ϣ
		Prompt prompt=new Prompt();
		panel.add(prompt);
		
		//������
		panel.add(new Piece(Color.BLUE,80,20,270,prompt));
		panel.add(new Piece(Color.BLUE,80,105,270,prompt));
		panel.add(new Piece(Color.RED,80,515,270,prompt));
		panel.add(new Piece(Color.RED,80,600,270,prompt));
		
		//������
		panel.add(new Piece(Color.BLUE,60,20,180,prompt));
		panel.add(new Piece(Color.BLUE,60,105,180,prompt));
		panel.add(new Piece(Color.RED,60,515,180,prompt));
		panel.add(new Piece(Color.RED,60,600,180,prompt));
		
		//С����
		panel.add(new Piece(Color.BLUE,40,20,110,prompt));
		panel.add(new Piece(Color.BLUE,40,105,110,prompt));
		panel.add(new Piece(Color.RED,40,515,110,prompt));
		panel.add(new Piece(Color.RED,40,600,110,prompt));
		
		//����
		panel.add(new Board());
		
		panel.add(new Block(new Color(94,131,168),0,430,700,20));
		
		//��λ��
		panel.add(new ResetButton(this));
	}
}
