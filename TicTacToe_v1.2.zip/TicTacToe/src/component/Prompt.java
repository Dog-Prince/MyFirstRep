package component;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.SwingConstants;

import gameState.GameState;

public class Prompt extends JLabel{
	public Prompt() {
		setText(String.format("P%d's turn", GameState.turn));
		setBounds(0, 395, 700, 20);
		setFont(new Font("Arial", Font.BOLD, 16));
		setHorizontalAlignment(SwingConstants.CENTER);
	}
}
