package component;

import java.awt.Color;
import java.awt.Graphics;
import java.awt.GridLayout;

import javax.swing.JPanel;
import javax.swing.border.LineBorder;

public class Board extends JPanel {
	//private Image image;
	private JPanel area[];
	public Board() {
		setBounds(200, 80, 300, 300);
		setBorder(new LineBorder(new Color(39,56,73),2));
		setLayout(new GridLayout(3, 3, 0, 0));
		
		area=new JPanel[9];
		for(int i=0;i<9;i++) {
			area[i]=new JPanel();
			if(i%2==0)
				area[i].setBackground(new Color(221,201,149));
			else
				area[i].setBackground(new Color(234,221,187));
			area[i].setBorder(new LineBorder(new Color(39,56,73),1));
			add(area[i]);
		}
	}
}
