package component;
import java.awt.Color;

import javax.swing.JPanel;

public class Block extends JPanel{
	public Block(Color color,int x, int y, int width, int height) {
		setBackground(color);
		setBounds(x, y, width, height);
	}
}
