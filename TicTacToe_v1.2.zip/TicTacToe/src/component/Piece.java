package component;

import java.awt.Color;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import javax.swing.JPanel;
import javax.swing.border.LineBorder;
import gameState.GameState;
import other.WinnerDialog;

public class Piece extends JPanel {
	int owner;
	int weight;
	int area=-1;
	private Prompt prompt;
	public Piece(Color color, int size, int startX, int startY, Prompt prompt) {
		owner= color==Color.BLUE ? 1 : 2;
		if(size==80)
			weight=4;
		else if(size==60)
			weight=2;
		else
			weight=1;
		this.prompt=prompt;
		setBounds(startX+(80-size)/2, startY+(80-size)/2, size, size);
		Color stuffColor=color==Color.BLUE?new Color(12,65,152):new Color(200,9,23);
		Color borderColor=color==Color.BLUE?new Color(14,96,233):new Color(247,60,73);
		setBorder(new LineBorder(borderColor, 3));
		setBackground(stuffColor);
		PieceMouseAdapter p = new PieceMouseAdapter(prompt);
		addMouseListener(p);
		addMouseMotionListener(p);
	}
}

class PieceMouseAdapter extends MouseAdapter{
	private int startX, startY;
	private int oldX, oldY, newX, newY;
	private Prompt prompt;
	
	public PieceMouseAdapter(Prompt prompt) {
		this.prompt=prompt;
	}
	
	public void mousePressed(MouseEvent e) {
		Piece piece=(Piece)e.getSource();
		if(GameState.turn==piece.owner) {
			startX=piece.getX();
			startY=piece.getY();
			oldX=e.getXOnScreen();
			oldY=e.getYOnScreen();
		}
	}

    public void mouseReleased(MouseEvent e) {
    	Piece piece=(Piece)e.getSource();
    	if(GameState.turn==piece.owner) {
    		newX=e.getXOnScreen();
    		newY=e.getYOnScreen();
    		int newArea=pieceArea(e);
    		int oldRow=piece.area/3,oldCol=piece.area%3;
			int newRow=newArea/3,newCol=newArea%3;
    		if(newArea!=-1&&piece.weight>GameState.p1State[newRow][newCol]&&piece.weight>GameState.p2State[newRow][newCol]) {
    			piece.setBounds(200+newCol*100+(100-piece.getWidth())/2, 80+newRow*100+(100-piece.getHeight())/2, piece.getWidth(), piece.getHeight());
    			if(GameState.turn==1) {
    				GameState.p1State[newRow][newCol]+=piece.weight;
    				if(piece.area!=-1)
    					GameState.p1State[oldRow][oldCol]-=piece.weight;
    				piece.area=newArea;
    				updateOwner();
    				GameState.turn=2;
    				prompt.setText("P2's turn");
    				checkWinner(prompt);
    			}
    			else{
    				GameState.p2State[newRow][newCol]+=piece.weight;
    				if(piece.area!=-1) 
    					GameState.p2State[oldRow][oldCol]-=piece.weight;
    				piece.area=newArea;
    				updateOwner();
    				GameState.turn=1;
    				prompt.setText("P1's turn");
    				checkWinner(prompt);
    			}
    		}
    		else
    			piece.setBounds(startX, startY, piece.getWidth(), piece.getHeight());
    	}
    }

    public void mouseDragged(MouseEvent e){
    	Piece piece=(Piece)e.getSource();
    	if(GameState.turn==piece.owner) {
    		newX=e.getXOnScreen();
    		newY=e.getYOnScreen();
    		
    		if(piece.area!=-1&&piece.weight>1&&(newX-oldX>20||newY-oldY>20)) {
    			int row=piece.area/3,col=piece.area%3;
    			int[][] ownState=piece.owner==1?GameState.p1State:GameState.p2State;
    			int[][] oppoState=piece.owner==1?GameState.p2State:GameState.p1State;
    			if(oppoState[row][col]!=0) {
    				ownState[row][col]-=piece.weight;
    				int oppoWeight=oppoState[row][col]>1?2:1;
    				if(piece.weight==4&&oppoWeight==1) {
    					if((newX-oldX>30||newY-oldY>30)) {
    						updateOwner();
    						checkWinner(prompt);
    					}
    				}
    				else {
    					updateOwner();
            			checkWinner(prompt);
    				}
    				ownState[row][col]+=piece.weight;
    				updateOwner();
    			}
    		}
    		
    		piece.setBounds(startX+(newX-oldX), startY+(newY-oldY), piece.getWidth(), piece.getHeight());
    	}
    }
    
    private int pieceArea(MouseEvent e) {
    	JPanel panel=(JPanel)e.getSource();
    	newX=e.getXOnScreen();
		newY=e.getYOnScreen();
    	int x=startX+(newX-oldX)-200+panel.getWidth()/2;
    	int y=startY+(newY-oldY)-80+panel.getHeight()/2;
    	if(x>0&&x<300&&y>0&&y<300)
    		return (y/100)*3+x/100;
    	return -1;
    }
    
    private void updateOwner() {
    	int o[][]=GameState.ownerState;
    	int p1[][]=GameState.p1State;
    	int p2[][]=GameState.p2State;
    	for(int i=0;i<3;i++) {
    		for(int j=0;j<3;j++) {
    			if(p1[i][j]>p2[i][j])
    				o[i][j]=1;
    			else if(p1[i][j]<p2[i][j])
    				o[i][j]=2;
    			else
    				o[i][j]=0;
    		}
    	}
    }
    
    private void checkWinner(Prompt prompt) {
    	int winner=0;
    	int s[][]=GameState.ownerState;
    	//�����
    	for(int i=0;i<3;i++) {
    		if(s[i][0]!=0&&s[i][0]==s[i][1]&&s[i][1]==s[i][2])
    			winner=s[i][0];
    	}
    	//�����
    	for(int j=0;j<3;j++) {
    		if(s[0][j]!=0&&s[0][j]==s[1][j]&&s[1][j]==s[2][j])
    			winner=s[0][j];
    	}
    	//���Խ���
    	if(s[0][0]!=0&&s[0][0]==s[1][1]&&s[1][1]==s[2][2])
    		winner=s[1][1];
    	if(s[0][2]!=0&&s[0][2]==s[1][1]&&s[1][1]==s[2][0])
    		winner=s[1][1];
    	
    	if(winner!=0) {
    		GameState.turn=0;
    		prompt.setText("Game Over");
    		WinnerDialog wd=new WinnerDialog(winner);
    	}
    }
}
