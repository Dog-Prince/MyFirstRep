package component;

import java.awt.Color;
import java.awt.Font;

import javax.swing.JLabel;
import javax.swing.SwingConstants;

public class Text extends JLabel {
	public Text(String str, int x, int y, int width, int height, Color color, int size){
		setText(str);
		setBounds(x, y, width, height);
		setFont(new Font("Arial", Font.BOLD, size));
		setForeground(color);
		setHorizontalAlignment(SwingConstants.CENTER);
	}
}
