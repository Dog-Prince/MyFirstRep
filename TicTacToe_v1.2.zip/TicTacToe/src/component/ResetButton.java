package component;

import java.awt.Color;
import java.awt.Font;
import java.awt.event.MouseAdapter;

import javax.swing.JButton;
import javax.swing.border.LineBorder;

import mainBody.TicTacToe;
import other.ResetMouseAdapter;

public class ResetButton extends JButton {
	public ResetButton(TicTacToe frame){
		setText("Reset");
		setBounds(560, 390, 70, 30);
		setFont(new Font("Arial", Font.BOLD, 13));
		setBackground(new Color(71,102,133));
		setForeground(Color.WHITE);
		setBorder(new LineBorder(new Color(69,98,126),3));
		setFocusPainted(false);
		MouseAdapter m=new ResetMouseAdapter(frame);
		addMouseListener(m);
	}
}
